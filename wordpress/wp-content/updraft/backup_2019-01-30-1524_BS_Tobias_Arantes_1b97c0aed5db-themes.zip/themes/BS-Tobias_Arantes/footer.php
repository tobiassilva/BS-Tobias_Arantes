






        <!-- igual o wp_head() tbm importa os scripts -->
        <?php wp_footer(); ?>

    </body>
</html>
<!-- Finaliza boddy e html iniciados no header -->
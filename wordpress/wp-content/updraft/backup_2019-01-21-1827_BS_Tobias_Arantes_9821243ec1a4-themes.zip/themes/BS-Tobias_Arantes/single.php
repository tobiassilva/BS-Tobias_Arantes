<!-- Quando clica em um post a proxima pagina a ser aberta com comentarios e links é essa -->

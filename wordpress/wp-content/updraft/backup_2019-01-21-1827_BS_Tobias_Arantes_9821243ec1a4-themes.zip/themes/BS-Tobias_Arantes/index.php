<?php get_header();?>

<!-- ABOUT US -->

<div class="divPagePar">
ABOUT US
</div>

<!-- SERVICE -->

<div class="divPageImpar">
SERVICE
</div>

<!-- WORK -->

<div class="divPagePar">
WORK
</div>

<!-- TEAM -->

<div class="divPageImpar">
TEAM
</div>

<!-- JOIN US -->

<div class="divPagePar">
JOIN US
</div>

<!-- BLOG -->

<div class="divPageImpar">
BLOG
</div>

<!-- PRODUCTS -->

<div class="divPagePar">
PRODUCTS
</div>

<!-- CONTACT US -->

<div class="divPagePar">
CONTACT US
</div>

<?php get_footer(); ?>